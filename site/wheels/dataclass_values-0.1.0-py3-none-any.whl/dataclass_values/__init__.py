"""dataclass_values: Value(...) carries a number's evidence; Space(obj) samples and checks it.

Domain-free and stdlib-only. See README.md.
"""

from .space import Space
from .values import (
    Basis,
    Choice,
    FloatValue,
    IntValue,
    LogUniform,
    Normal,
    StrValue,
    TupleValue,
    Uniform,
    Value,
    meta,
    plain,
    v,
)

__all__ = [
    "Basis",
    "Choice",
    "FloatValue",
    "IntValue",
    "LogUniform",
    "Normal",
    "Space",
    "StrValue",
    "TupleValue",
    "Uniform",
    "Value",
    "meta",
    "plain",
    "v",
]
