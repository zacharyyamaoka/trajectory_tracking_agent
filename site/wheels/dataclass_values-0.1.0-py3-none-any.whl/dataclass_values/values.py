"""A number (or string) that remembers where it came from, and still is the number.

    width_m = Value(1.2, "m", low=0.6, high=1.85, basis=Basis.CHOSEN, source="…")
    v = Value                       # optional short alias; the real name is the readable one

WHY `Value(...)` reads like a type cast (Zach, Oct 5 2026): "v should be v = Value, v as Value, it's
like a type casting; the actual thing needs a readable name". `Value(1.2, "m")` returns a
FloatValue, so `isinstance(x, Value)` and `isinstance(x, float)` are both true.
WHY a float subclass and not a wrapper: "I definitely don't want to have to do width_m.value". The
class keeps `width_m: float`, `belt.width_m * 2` is a plain 2.4, ROS/numpy see a float, and the
evidence rides along.
WHY the value is first and unnamed, unit optionally second: both are obvious at a glance; everything
else is keyword-only, so the old positional puzzle (est(…, C, 0.6, 1.85)) cannot come back.
WHY arithmetic returns a plain number: a derived number is a new claim and must not inherit the
original's source.
WHY a tuple carrier: a vector (xyz, a limit pair) is one claim with one source;
`Value((0.0, 0.0, 0.3), "m")` is still a tuple, and `low`/`high` given as tuples are checked
elementwise.
WHY its own package (Zach, Nov 10 2026): "the pydataclass syntax can technically apply to any
domain! robot_msgs is just a particular domain." Domain-free, stdlib only.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, fields, is_dataclass, replace
from enum import StrEnum
from typing import overload


class Basis(StrEnum):
    """Where a number comes from (CHOSEN..ASSUMED match bam_facility_model.estimate.Basis)."""

    CHOSEN = "chosen"
    DATASHEET = "datasheet"
    MARKET = "market"
    ASSUMED = "assumed"
    MEASURED = "measured"
    SAMPLED = "sampled"  # drawn by Space.sample() from this value's range, choices or distribution


# --- distributions: per-value, first class ---
@dataclass(frozen=True)
class Uniform:
    low: float
    high: float

    def draw(self, rng: random.Random) -> float:
        return rng.uniform(self.low, self.high)


@dataclass(frozen=True)
class Normal:
    mean: float
    std: float

    def draw(self, rng: random.Random) -> float:
        return rng.gauss(self.mean, self.std)


@dataclass(frozen=True)
class LogUniform:
    low: float
    high: float

    def draw(self, rng: random.Random) -> float:
        return math.exp(rng.uniform(math.log(self.low), math.log(self.high)))


@dataclass(frozen=True)
class Choice:
    """A discrete distribution: options with optional weights."""

    options: tuple
    weights: tuple | None = None

    def draw(self, rng: random.Random):
        return rng.choices(self.options, weights=self.weights)[0]


Distribution = Uniform | Normal | LogUniform | Choice

META = (
    "unit",
    "low",
    "high",
    "step",
    "choices",
    "dist",
    "basis",
    "source",
    "measured_by",
    "notes",
    "date_accessed",
)


def within(raw, low, high) -> bool:
    """low <= raw <= high; for a tuple raw, elementwise (a scalar bound applies to each element)."""
    if isinstance(raw, tuple):
        lows = low if isinstance(low, tuple) else (low,) * len(raw)
        highs = high if isinstance(high, tuple) else (high,) * len(raw)
        if len(lows) != len(raw) or len(highs) != len(raw):
            raise ValueError(f"{raw!r} has {len(raw)} elements but low={low!r}, high={high!r}")
        return all(lo <= x <= hi for lo, x, hi in zip(lows, raw, highs, strict=True))
    return low <= raw <= high


def _rebuild(cls, raw, meta):
    meta = dict(meta)
    unit = meta.pop("unit")  # unit is positional-only in the constructor
    return cls(raw, unit, **meta)


class Value:
    """`Value(raw, unit=None, *, low, high, step, choices, dist, basis, source, ...)`.

    Calling Value(...) picks the carrier for the raw type (FloatValue / IntValue / StrValue /
    TupleValue), each of which subclasses both Value and the builtin. bool and None cannot carry
    evidence: Python forbids subclassing them.
    """

    _base: type = object

    @overload
    def __new__(
        cls,
        raw: int,
        unit: str | None = None,
        /,
        *,
        low: float | None = None,
        high: float | None = None,
        step: float | None = None,
        choices: tuple | None = None,
        dist: Distribution | None = None,
        basis: Basis | None = None,
        source: str = "",
        measured_by: str = "",
        notes: str = "",
        date_accessed: str = "",
    ) -> IntValue: ...

    @overload
    def __new__(
        cls,
        raw: float,
        unit: str | None = None,
        /,
        *,
        low: float | None = None,
        high: float | None = None,
        step: float | None = None,
        choices: tuple | None = None,
        dist: Distribution | None = None,
        basis: Basis | None = None,
        source: str = "",
        measured_by: str = "",
        notes: str = "",
        date_accessed: str = "",
    ) -> FloatValue: ...

    @overload
    def __new__(
        cls,
        raw: str,
        unit: str | None = None,
        /,
        *,
        low: None = None,
        high: None = None,
        step: None = None,
        choices: tuple | None = None,
        dist: Distribution | None = None,
        basis: Basis | None = None,
        source: str = "",
        measured_by: str = "",
        notes: str = "",
        date_accessed: str = "",
    ) -> StrValue: ...

    @overload
    def __new__(
        cls,
        raw: tuple,
        unit: str | None = None,
        /,
        *,
        low: float | tuple | None = None,
        high: float | tuple | None = None,
        step: float | None = None,
        choices: tuple | None = None,
        dist: Distribution | None = None,
        basis: Basis | None = None,
        source: str = "",
        measured_by: str = "",
        notes: str = "",
        date_accessed: str = "",
    ) -> TupleValue: ...

    def __new__(
        cls,
        raw=None,
        unit=None,
        /,
        *,
        low=None,
        high=None,
        step=None,
        choices=None,
        dist=None,
        basis=None,
        source="",
        measured_by="",
        notes="",
        date_accessed="",
    ):
        if cls is Value:
            if isinstance(raw, bool) or raw is None:
                raise TypeError(
                    "bool and None cannot carry evidence (Python forbids subclassing them); "
                    "leave them plain"
                )
            for base, carrier in (
                (float, FloatValue),
                (int, IntValue),
                (str, StrValue),
                (tuple, TupleValue),
            ):
                if isinstance(raw, base):
                    cls = carrier
                    break
            else:
                raise TypeError(f"Value wraps float, int, str or tuple, not {type(raw).__name__}")
        obj = cls._base.__new__(cls, raw)
        meta = dict(
            unit=unit,
            low=low,
            high=high,
            step=step,
            choices=tuple(choices) if choices is not None else None,
            dist=dist,
            basis=basis,
            source=source,
            measured_by=measured_by,
            notes=notes,
            date_accessed=date_accessed,
        )
        for k, val in meta.items():
            object.__setattr__(obj, k, val)
        if low is not None and high is not None and not within(raw, low, high):
            raise ValueError(
                f"{raw!r} outside [{low}, {high}] ({source or unit or ''})".rstrip(" ()")
            )
        if meta["choices"] is not None and raw not in meta["choices"]:
            raise ValueError(f"{raw!r} not one of {meta['choices']}")
        return obj

    def __init__(self, *args, **kwargs):  # all work happens in __new__
        pass

    def __setattr__(self, key, val):
        raise AttributeError(
            f"{type(self).__name__} is immutable; write a new Value(...) in the source"
        )

    def __reduce__(self):  # copy, deepcopy, asdict and pickle rebuild through __new__
        return (_rebuild, (type(self), self._base(self), self.meta()))

    @property
    def value(self):
        """The plain builtin. New code just uses the value itself."""
        return self._base(self)

    def meta(self) -> dict:
        return {k: getattr(self, k) for k in META}


class FloatValue(Value, float):
    _base = float


class IntValue(Value, int):
    _base = int


class StrValue(Value, str):
    _base = str


class TupleValue(Value, tuple):
    """A vector or pair that remembers where it came from.

    `Value((0.0, 0.0, 0.3), "m", low=(-1, -1, 0), high=(1, 1, 2))`.
    """

    _base = tuple


v = Value  # the optional short alias


def meta(x) -> dict | None:
    """The evidence on a value, or None for a plain one."""
    return x.meta() if isinstance(x, Value) else None


def plain(obj):
    """The same object with every Value replaced by its builtin: for ROS, JSON and the like."""
    if isinstance(obj, TupleValue):
        return tuple(plain(x) for x in obj)
    if is_dataclass(obj) and not isinstance(obj, type):
        return replace(obj, **{f.name: plain(getattr(obj, f.name)) for f in fields(obj) if f.init})
    if isinstance(obj, (list, tuple)):
        return type(obj)(plain(x) for x in obj)
    return obj.value if isinstance(obj, Value) else obj
