"""Space: an instance seen as a space (gymnasium-style), derived from the instance itself.

    from dataclass_values import Space, Value
    pick = Pose(position=Point(x=Value(0.5, "m", low=0.4, high=0.6), y=0.0, z=0.3))
    Space(pick).sample(rng)          # -> a Pose, x drawn in [0.4, 0.6], marked basis=SAMPLED
    Space(pick).contains(measured)   # -> the acceptable range in a test
    Space(pick).violations(measured) # -> ["position.x=0.7 outside [0.4, 0.6]"]

WHY the same class and a derived space (Zach, Oct 5 2026, "do not re-litigate"): a second
`PoseSpace` / `CheckedBelt` class "drifts" from the message it shadows. So a field carries its own
range as a `Value`, which IS the builtin float/int/str/tuple, and `Space(obj)` is a view over the
instance whose `sample()` returns the ordinary class. Nothing is discarded: the authored instance is
untouched, and each drawn value keeps its unit, range and source, marked basis=SAMPLED. Call
`plain()` only at a runtime boundary where you choose to drop the notes.

Subclasses add kinds of bound the scalar core knows nothing about (robot_msgs bounds numpy array
fields) by overriding the two hooks `extra_draw` and `extra_violations`.
"""

from __future__ import annotations

import random
from dataclasses import fields, is_dataclass, replace
from typing import Any

from .values import META, Basis, TupleValue, Value, meta, plain, within


class Space:
    """Every `Value` in `instance` with a dist, choices or [low, high] can be drawn and checked."""

    def __init__(self, instance: Any) -> None:
        self.instance = instance

    # ── sampling ──────────────────────────────────────────────────────────────

    def sample(self, rng: random.Random | None = None):
        """The same class as the instance, every ranged Value redrawn (basis=SAMPLED)."""
        rng = rng or random.Random()
        return self.extra_draw(self._draw(self.instance, rng), rng)

    def extra_draw(self, drawn, rng: random.Random):
        """Hook: take the already-drawn instance and redraw whatever else this space bounds."""
        return drawn

    def _draw(self, x, rng):
        if is_dataclass(x) and not isinstance(x, type):
            return replace(
                x, **{f.name: self._draw(getattr(x, f.name), rng) for f in fields(x) if f.init}
            )
        if isinstance(x, TupleValue) and x.dist is None and x.choices is None:
            return x  # a vector is one claim: drawn only through its own choices or dist
        if isinstance(x, (list, tuple)) and not isinstance(x, TupleValue):
            return type(x)(self._draw(i, rng) for i in x)
        m = meta(x)
        if not m or (
            m["dist"] is None and m["choices"] is None and (m["low"] is None or m["high"] is None)
        ):
            return x
        if m["dist"] is not None:
            drawn = m["dist"].draw(rng)
        elif m["choices"] is not None:
            drawn = rng.choice(m["choices"])
        else:
            drawn = rng.uniform(m["low"], m["high"])
        if isinstance(drawn, (int, float)) and not isinstance(drawn, bool):
            if m["low"] is not None:
                drawn = max(m["low"], drawn)
            if m["high"] is not None:
                drawn = min(m["high"], drawn)
            if isinstance(x, int):
                drawn = round(drawn)
            if m["step"]:
                base = m["low"] if m["low"] is not None else 0
                drawn = base + round((drawn - base) / m["step"]) * m["step"]
                drawn = round(drawn) if isinstance(x, int) else drawn
        return Value(
            drawn,
            m["unit"],
            **{
                **{k: m[k] for k in META if k != "unit"},
                "basis": Basis.SAMPLED,
                "notes": f"sampled from {x!r}" + (f"; {m['notes']}" if m["notes"] else ""),
            },
        )

    # ── checking ──────────────────────────────────────────────────────────────

    def contains(self, other: Any) -> bool:
        """True when every ranged field of `other` lies inside this space."""
        return not self.violations(other)

    def violations(self, other: Any) -> list[str]:
        """One line per field of `other` outside its range: ``position.x=0.7 outside [0.4, 0.6]``"""
        if type(other) is not type(self.instance):
            raise TypeError(
                f"a {type(self.instance).__name__} space cannot hold a {type(other).__name__}"
            )
        found: list[str] = []
        self._check(self.instance, other, "", found)
        found.extend(self.extra_violations(other))
        return found

    def extra_violations(self, other: Any) -> list[str]:
        """Hook: one line per way `other` breaks a bound this space adds beyond the scalar ones."""
        return []

    def _check(self, ranged, other, path, found):
        if is_dataclass(ranged) and not isinstance(ranged, type):
            for f in fields(ranged):
                self._check(
                    getattr(ranged, f.name), getattr(other, f.name), f"{path}{f.name}.", found
                )
            return
        m = meta(ranged)
        if not m:
            return
        name = path.rstrip(".")
        if (
            m["low"] is not None
            and m["high"] is not None
            and not within(other, m["low"], m["high"])
        ):
            found.append(f"{name}={plain(other)!r} outside [{m['low']}, {m['high']}]")
        elif m["choices"] is not None and other not in m["choices"]:
            found.append(f"{name}={plain(other)!r} not one of {m['choices']}")
